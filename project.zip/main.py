from machine import Pin   # Import Pin class to control GPIO
import time               # Import time module for delays

buzzer = Pin(8, Pin.OUT)   # Set GPIO 28 as an output (LED)
button = Pin(9, Pin.IN, Pin.PULL_UP)  # Set GPIO 9 as input with internal pull-up resistor

while True:    
    # Check button state
    # With pull-up: 
    # - Not pressed → reads 1 (HIGH)
    # - Pressed → reads 0 (connected to GND)
    if button.value() == 0:
        buzzer.high()   # Turn LED ON when button is pressed (LOW)
    else:
        buzzer.low()  # Turn LED OFF when button is not pressed (HIGH)
    
    time.sleep(0.2)  # Small delay to reduce CPU usage and simple debounce